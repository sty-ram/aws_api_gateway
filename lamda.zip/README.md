# api gate_way lambda function to coect remote db 
'''
 # to add all the files in the venv write this comand in terminal 
# `" pip install -r requirment.txt -t"`